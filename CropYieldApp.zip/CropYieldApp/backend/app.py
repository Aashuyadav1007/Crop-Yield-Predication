from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import joblib
import pandas as pd
import os

app = FastAPI(title="Crop Yield Predictor")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MODEL_PATH = os.path.join(os.path.dirname(__file__), 'rf_model.joblib')
model = None

# We will load the model on startup
@app.on_event("startup")
def load_model():
    global model
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
        print("Model loaded successfully.")
    else:
        print("Warning: Model file not found. Prediction will fail unless model is trained.")

class PredictionRequest(BaseModel):
    # Location feature
    Region: str
    
    # Soil & Crop
    Soil_Type: str
    Crop: str
    
    # Environmental
    Rainfall_mm: float
    Temperature_Celsius: float
    Weather_Condition: Optional[str] = None
    
    # Farming Practices
    Fertilizer_Used: bool
    Irrigation_Used: bool
    
    # Timeline
    Days_to_Harvest: int

@app.get("/")
def read_root():
    return {"message": "Crop Yield Prediction API is active."}

@app.post("/predict")
def predict_yield(req: PredictionRequest):
    if model is None:
        raise HTTPException(status_code=500, detail="Model is not loaded. Please train the model first.")
    
    try:
        # Convert request to dataframe
        data = {
            'Region': [req.Region],
            'Soil_Type': [req.Soil_Type],
            'Crop': [req.Crop],
            'Rainfall_mm': [req.Rainfall_mm],
            'Temperature_Celsius': [req.Temperature_Celsius],
            'Weather_Condition': [req.Weather_Condition],
            'Fertilizer_Used': [int(req.Fertilizer_Used)],
            'Irrigation_Used': [int(req.Irrigation_Used)],
            'Days_to_Harvest': [req.Days_to_Harvest]
        }
        df = pd.DataFrame(data)
        
        # Predict
        prediction = model.predict(df)
        
        return {"predicted_yield_kg_per_hectare": round(float(prediction[0]) * 1000, 2)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
