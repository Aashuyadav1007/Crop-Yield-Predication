import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Select from 'react-select';
import DatePicker from 'react-datepicker';
import { differenceInDays, addDays } from 'date-fns';
import { Slider, CircularProgress } from '@mui/material';
import { Switch, message } from 'antd';
import { Leaf, MapPin, Droplet, Thermometer, Settings, Calendar, Award, Sprout, Tractor, CloudSun, Wind } from 'lucide-react';
import indianData from './indianDistricts.json';

const STATE_REGION_MAP = {
  "Jammu and Kashmir": "North", "Himachal Pradesh": "North", "Punjab": "North", "Chandigarh (UT)": "North", "Uttarakhand": "North", "Haryana": "North", "Delhi (NCT)": "North", "Uttar Pradesh": "North", "Rajasthan": "North",
  "Andhra Pradesh": "South", "Karnataka": "South", "Kerala": "South", "Tamil Nadu": "South", "Telangana": "South", "Puducherry (UT)": "South", "Lakshadweep (UT)": "South", "Andaman and Nicobar Islands": "South",
  "Bihar": "East", "Jharkhand": "East", "Odisha": "East", "West Bengal": "East", "Sikkim": "East", "Assam": "East", "Arunachal Pradesh": "East", "Nagaland": "East", "Manipur": "East", "Mizoram": "East", "Tripura": "East", "Meghalaya": "East",
  "Gujarat": "West", "Maharashtra": "West", "Goa": "West", "Dadra and Nagar Haveli (UT)": "West", "Daman and Diu (UT)": "West", "Madhya Pradesh": "West", "Chhattisgarh": "West"
};

const SOIL_TYPES = [
  { value: 'Sandy', label: 'Sandy' },
  { value: 'Loam', label: 'Loam' },
  { value: 'Clay', label: 'Clay' },
  { value: 'Silt', label: 'Silt' },
  { value: 'Peaty', label: 'Peaty' },
  { value: 'Chalky', label: 'Chalky' }
];

const CROPS = [
  { value: 'Wheat', label: 'Wheat' },
  { value: 'Rice', label: 'Rice' },
  { value: 'Cotton', label: 'Cotton' },
  { value: 'Soybean', label: 'Soybean' },
  { value: 'Maize', label: 'Maize' },
  { value: 'Sugarcane', label: 'Sugarcane' },
  { value: 'Barley', label: 'Barley' }
];

const WEATHER_CONDITIONS = [
  { value: 'Sunny', label: 'Sunny' },
  { value: 'Cloudy', label: 'Cloudy' },
  { value: 'Rainy', label: 'Rainy' }
];

export default function App() {
  const [formData, setFormData] = useState({
    Region: null,
    State: null,
    District: null,
    Soil_Type: null,
    Crop: null,
    Rainfall_mm: 500,
    Temperature_Celsius: 25,
    Weather_Condition: null,
    Fertilizer_Used: false,
    Irrigation_Used: false,
  });

  const [dates, setDates] = useState({
    plantingDate: new Date(),
    harvestDate: addDays(new Date(), 90)
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [isAnimatingResult, setIsAnimatingResult] = useState(false);
  const [weatherData, setWeatherData] = useState(null);
  const [districtOptions, setDistrictOptions] = useState([]);

  const allStates = indianData.states.map(s => ({ value: s.state, label: s.state }));

  useEffect(() => {
    // Fetch live weather data using Open-Meteo API
    const fetchWeather = async (lat, lon) => {
      try {
        const res = await axios.get(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
        setWeatherData(res.data.current_weather);
      } catch (err) {
        console.error("Failed to fetch weather data: ", err);
      }
    };

    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(
        (position) => fetchWeather(position.coords.latitude, position.coords.longitude),
        () => fetchWeather(28.6139, 77.2090) // Fallback to New Delhi
      );
    } else {
      fetchWeather(28.6139, 77.2090);
    }
  }, []);

  useEffect(() => {
    if (formData.State) {
      const stateName = formData.State.value;
      const stateObj = indianData.states.find(s => s.state === stateName);
      if (stateObj) {
        setDistrictOptions(stateObj.districts.map(d => ({ value: d, label: d })));
      } else {
        setDistrictOptions([]);
      }
      
      const region = STATE_REGION_MAP[stateName] || "North"; 
      setFormData(prev => ({ ...prev, Region: { value: region, label: region }, District: null }));
    } else {
      setDistrictOptions([]);
      setFormData(prev => ({ ...prev, Region: null, District: null }));
    }
  }, [formData.State]);

  useEffect(() => {
    if (formData.District && formData.State) {
      const fetchDistrictWeather = async () => {
        try {
          const districtName = formData.District.value;
          const searchName = districtName.split('(')[0].trim();
          const geoRes = await axios.get(`https://geocoding-api.open-meteo.com/v1/search?name=${searchName}&count=1&language=en&format=json`);
          
          if (geoRes.data.results && geoRes.data.results.length > 0) {
            const lat = geoRes.data.results[0].latitude;
            const lon = geoRes.data.results[0].longitude;

            const weatherRes = await axios.get(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,precipitation&timezone=auto`);
            
            if (weatherRes.data.current) {
              setFormData(prev => ({
                ...prev,
                Temperature_Celsius: weatherRes.data.current.temperature_2m,
                Rainfall_mm: weatherRes.data.current.precipitation
              }));
              message.success(`Live weather synced: ${weatherRes.data.current.temperature_2m}°C, ${weatherRes.data.current.precipitation}mm rain for ${districtName}`);
            }
          } else {
            console.warn("Could not find coordinates for " + districtName);
          }
        } catch (err) {
          console.error("Failed to fetch district weather:", err);
        }
      };
      fetchDistrictWeather();
    }
  }, [formData.District, formData.State]);

  const handleSelectChange = (name) => (selectedOption) => {
    setFormData(prev => ({ ...prev, [name]: selectedOption }));
  };

  const handleSliderChange = (name) => (event, newValue) => {
    setFormData(prev => ({ ...prev, [name]: newValue }));
  };

  const handleToggleChange = (name) => (checked) => {
    setFormData(prev => ({ ...prev, [name]: checked }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.Region || !formData.Soil_Type || !formData.Crop) {
      message.error("Please fill all required dropdowns first.");
      return;
    }

    const daysToHarvest = differenceInDays(dates.harvestDate, dates.plantingDate);
    if (daysToHarvest <= 0) {
      message.error("Harvest date must be after planting date.");
      return;
    }

    setLoading(true);
    setResult(null);

    const payload = {
      Region: formData.Region.value,
      Soil_Type: formData.Soil_Type.value,
      Crop: formData.Crop.value,
      Rainfall_mm: formData.Rainfall_mm,
      Temperature_Celsius: formData.Temperature_Celsius,
      Weather_Condition: formData.Weather_Condition ? formData.Weather_Condition.value : null,
      Fertilizer_Used: formData.Fertilizer_Used,
      Irrigation_Used: formData.Irrigation_Used,
      Days_to_Harvest: daysToHarvest
    };

    try {
      const response = await axios.post('http://localhost:8000/predict', payload);
      const output = response.data.predicted_yield_kg_per_hectare;
      
      // Start Tractor Animation
      setLoading(false);
      setIsAnimatingResult(true);
      await new Promise(r => setTimeout(r, 2500));
      
      setResult(output);
    } catch (err) {
      console.error(err);
      message.error(err.response?.data?.detail || "An error occurred fetching prediction");
    } finally {
      setLoading(false);
      setIsAnimatingResult(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans relative">
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/hero-bg.png')" }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-white/90 via-white/40 to-black/60"></div>
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Navigation */}
        <nav className="flex items-center justify-between px-6 py-4 lg:px-12 bg-white/80 backdrop-blur-md sticky top-0 z-50 shadow-sm">
          <div className="flex items-center gap-2 cursor-pointer">
            <Sprout className="w-8 h-8 text-primary-700" />
            <span className="text-2xl font-bold text-gray-800 tracking-tight">CropPredict AI</span>
          </div>
          

        </nav>

        {/* Live Weather Bar */}
        {weatherData && (
          <div className="bg-[#1f3d32] text-white py-2 px-6 flex justify-center items-center gap-6 shadow-md text-sm font-medium z-40 relative animate-pulse-weather">
            <div className="flex items-center gap-2">
              <CloudSun className="w-4 h-4 text-yellow-300" />
              <span>Live Weather</span>
            </div>
            <div className="flex items-center gap-2 border-l border-white/20 pl-6">
              <Thermometer className="w-4 h-4 text-red-300" />
              <span>{weatherData.temperature}°C</span>
            </div>
            <div className="flex items-center gap-2 border-l border-white/20 pl-6">
              <Wind className="w-4 h-4 text-blue-200" />
              <span>{weatherData.windspeed} km/h (Wind)</span>
            </div>
          </div>
        )}

        {/* Hero Section */}
        <div className="flex-1 flex flex-col items-center pt-20 px-6 text-center">
          <h1 className="text-5xl md:text-6xl font-extrabold text-[#1f3d32] mb-6 leading-tight max-w-4xl tracking-tight animate-fade-in">
            Maximize Your Harvest with Data-Driven Insights
          </h1>
          <p className="text-xl md:text-2xl text-gray-800 mb-10 max-w-3xl font-medium animate-fade-in" style={{animationDelay: '0.1s'}}>
            Predict crop yields accurately using AI, satellite data, and weather analytics for optimized farming.
          </p>
          
          <div className="flex items-center gap-4 mb-20 animate-fade-in" style={{animationDelay: '0.2s'}}>
            <a href="#dashboard" className="px-8 py-3.5 bg-[#2B6049] hover:bg-[#204a37] text-white font-semibold rounded-lg transition shadow-[0_4px_14px_0_rgba(43,96,73,0.39)] text-lg">
              Get Yield Forecast
            </a>
          </div>

          {/* Form / Mock Dashboard Element */}
          <div id="dashboard" className="w-full max-w-6xl mx-auto bg-white/95 backdrop-blur-xl rounded-3xl shadow-2xl p-6 md:p-10 border border-white/40 mb-20 animate-fade-in-delayed">
            <div className="flex items-center gap-3 mb-8 pb-4 border-b border-gray-200">
              <Leaf className="w-6 h-6 text-primary-600" />
              <h2 className="text-2xl font-bold text-gray-800 uppercase tracking-widest text-sm">Crop Yield Prediction</h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-10 text-left">
              
              {/* Location Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">Country</label>
                  <input type="text" disabled value="India" className="w-full px-4 py-[9px] bg-gray-100 border border-gray-200 rounded-lg cursor-not-allowed text-gray-500 font-medium"/>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">State</label>
                  <Select options={allStates} value={formData.State} onChange={handleSelectChange('State')} isClearable placeholder="Select State" className="text-sm font-medium"/>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">District</label>
                  <Select options={districtOptions} value={formData.District} onChange={handleSelectChange('District')} isClearable placeholder="Select District" isDisabled={!formData.State} className="text-sm font-medium"/>
                </div>
              </div>

              {/* Crop Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">Soil Type</label>
                  <Select options={SOIL_TYPES} value={formData.Soil_Type} onChange={handleSelectChange('Soil_Type')} isClearable placeholder="Select Soil"/>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">Crop</label>
                  <Select options={CROPS} value={formData.Crop} onChange={handleSelectChange('Crop')} isClearable placeholder="Select Crop"/>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">Weather Condition (Optional)</label>
                  <Select options={WEATHER_CONDITIONS} value={formData.Weather_Condition} onChange={handleSelectChange('Weather_Condition')} isClearable placeholder="Select Weather"/>
                </div>
              </div>

              {/* Sliders Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 bg-gray-50/50 p-6 rounded-2xl border border-gray-100">
                <div>
                  <label className="flex items-center gap-2 text-sm font-semibold mb-4 text-gray-600">
                    <Droplet className="w-4 h-4 text-blue-500" /> Rainfall (mm): <span className="text-blue-600 ml-1">{formData.Rainfall_mm}</span>
                  </label>
                  <Slider value={formData.Rainfall_mm} onChange={handleSliderChange('Rainfall_mm')} min={0} max={3000} sx={{ color: '#3b82f6', height: 8 }}/>
                </div>
                <div>
                  <label className="flex items-center gap-2 text-sm font-semibold mb-4 text-gray-600">
                    <Thermometer className="w-4 h-4 text-red-500" /> Avg Temperature (°C): <span className="text-red-500 ml-1">{formData.Temperature_Celsius}</span>
                  </label>
                  <Slider value={formData.Temperature_Celsius} onChange={handleSliderChange('Temperature_Celsius')} min={-10} max={60} sx={{ color: '#ef4444', height: 8 }}/>
                </div>
              </div>

              {/* Dates & Switches */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">Planting Date</label>
                  <DatePicker selected={dates.plantingDate} onChange={(date) => setDates(prev => ({ ...prev, plantingDate: date }))} className="w-full px-4 py-[9px] border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#2B6049]"/>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-gray-600">Estimated Harvest Date</label>
                  <DatePicker selected={dates.harvestDate} onChange={(date) => setDates(prev => ({ ...prev, harvestDate: date }))} minDate={dates.plantingDate} className="w-full px-4 py-[9px] border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#2B6049]"/>
                </div>
                <div className="flex items-center justify-between px-4 py-[9px] border border-gray-200 rounded-lg bg-gray-50">
                  <span className="font-semibold text-gray-600 text-sm">Fertilizer Used</span>
                  <Switch checked={formData.Fertilizer_Used} onChange={handleToggleChange('Fertilizer_Used')} style={{ background: formData.Fertilizer_Used ? '#2B6049' : 'rgba(0,0,0,0.25)' }}/>
                </div>
                <div className="flex items-center justify-between px-4 py-[9px] border border-gray-200 rounded-lg bg-gray-50">
                  <span className="font-semibold text-gray-600 text-sm">Irrigation Used</span>
                  <Switch checked={formData.Irrigation_Used} onChange={handleToggleChange('Irrigation_Used')} style={{ background: formData.Irrigation_Used ? '#3b82f6' : 'rgba(0,0,0,0.25)' }}/>
                </div>
              </div>

              {/* Submit Action */}
              <div className="flex justify-start pt-6 border-t border-gray-200">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full md:w-auto px-10 py-3 bg-[#2B6049] hover:bg-[#204a37] text-white font-bold rounded-lg shadow-lg transform transition active:scale-95 focus:ring-4 focus:ring-[#2B6049]/50 disabled:opacity-70 disabled:active:scale-100 flex items-center justify-center gap-3"
                >
                  {loading ? <CircularProgress size={20} color="inherit" /> : <><Award className="w-5 h-5"/> Predict Crop Yield</>}
                </button>
              </div>
            </form>

            {/* Results Panel & Animations */}
            {isAnimatingResult && (
              <div className="mt-10 overflow-hidden relative h-32 bg-[#e8f3ee] border-2 border-[#2B6049]/20 rounded-2xl flex items-center shadow-inner">
                <div className="absolute animate-tractor">
                  <Tractor className="w-16 h-16 text-[#2B6049]" />
                </div>
                <p className="w-full text-center text-[#2B6049] font-bold text-lg animate-pulse">Calculating optimal yield layout...</p>
              </div>
            )}

            {!isAnimatingResult && result !== null && (
               <div className="mt-10 space-y-4 animate-fade-in">
                 <div className="bg-green-50 border-2 border-green-500/20 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between shadow-sm">
                   <div>
                     <h3 className="text-xl font-bold text-gray-800 mb-1 flex items-center gap-2">
                       <Award className="w-6 h-6 text-green-600" /> Yield Forecast Output
                     </h3>
                     <p className="text-gray-500 text-sm font-medium">Mapped to region: {formData.Region?.value || 'N/A'}</p>
                   </div>
                   <div className="text-right mt-4 md:mt-0">
                     <p className="text-5xl font-black text-green-700">
                       {result.toLocaleString('en-IN')} <span className="text-xl font-semibold text-green-600/70">kg/ha</span>
                     </p>
                   </div>
                 </div>
                 
                 {/* Unit Conversions Grid */}
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                   <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
                     <span className="text-gray-500 font-semibold text-sm uppercase tracking-wide">Per Acre</span>
                     <span className="text-gray-800 font-bold text-lg">{(result / 2.47105).toFixed(2)} kg</span>
                   </div>
                   <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
                     <span className="text-gray-500 font-semibold text-sm uppercase tracking-wide">Per Bigha</span>
                     <span className="text-gray-800 font-bold text-lg">{(result / 3.953686).toFixed(2)} kg</span>
                   </div>
                   <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
                     <span className="text-gray-500 font-semibold text-sm uppercase tracking-wide">Per Gaj</span>
                     <span className="text-gray-800 font-bold text-lg">{(result / 11959.9).toFixed(3)} kg</span>
                   </div>
                 </div>
               </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
